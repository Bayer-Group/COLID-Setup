Document Clustering Server
--------------------------

The Document Clustering Server exposes Carrot2 clustering algorithms
as a HTTP/REST service.

To run the DCS, execute the 'dcs' script, it starts the server at the
default address of: http://localhost:8080


Build: @version@, @gitRev@, @buildDate@