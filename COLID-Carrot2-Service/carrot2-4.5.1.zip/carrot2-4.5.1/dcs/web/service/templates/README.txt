Place request templates in this folder. 

Templates are returned from the service in the order of alphabetic file names. 
The returned template identifiers are stripped of any numeric prefix and file 
name extension. For example, a template "04 stc-fast-settings.json" would have
an identifier "stc-fast-settings".
