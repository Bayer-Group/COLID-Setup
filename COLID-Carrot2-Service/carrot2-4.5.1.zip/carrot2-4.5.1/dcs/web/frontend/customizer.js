export default app => {
  app.on("clusteringRequested", e => {
  });
};